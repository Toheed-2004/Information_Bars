"""Information bar generation pipeline."""

"""Information bar generation pipeline."""
